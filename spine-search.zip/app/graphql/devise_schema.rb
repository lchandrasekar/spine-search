DeviseSchema = GraphQL::Schema.define do
  mutation(Types::DeviseType)
end
