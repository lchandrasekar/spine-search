FactoryBot.define do
  factory :foreign_prospect_mapping do
    lead_id ""
    prospected_by_company_id ""
    foreign_id ""
  end
end
