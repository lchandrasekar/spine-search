FactoryBot.define do
  factory :prospect do
    full_name "MyString"
    image_url "MyString"
    last_processed "MyString"
    prospected_by_company_id "MyString"
    prospected_by_user_id "MyString"
    lead_id "MyString"
    account_id "MyString"
    title "MyString"
  end
end
